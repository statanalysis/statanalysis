
path="E:\Projects\VisualCal\\"
'''import Statements'''
import win32com.client
import pandas as pd
import glob, os, shutil
os.system('taskkill /f /im Excel.exe')
if os.path.exists(path+"executed"):
  shutil.rmtree(path+"executed")

if not os.path.exists(path+"executed"):
  os.makedirs(path+"executed")



files = glob.iglob(os.path.join(path, "*.xlsx"))
for file in files:
  if '~' not in file:
    import win32com.client
    filename = file
    print(filename)
    sheetname = 'Sheet1'
    xl = win32com.client.DispatchEx('Excel.Application')
    wb = xl.Workbooks.Open(Filename=filename) 
    ws = wb.Sheets(sheetname)
    '''remove empty row from excel files'''
    begrow = 1
    endrow = ws.UsedRange.Rows.Count
    
    count=-2    
    for row in range(begrow,endrow+1):
         
         if "float" in str(type(ws.Range('A{}'.format(row)).Value)):
             break
         else:
             count=count+1
    
    while count>=0:
        ws.Range('A{}'.format(begrow)).EntireRow.Delete(Shift=-4162)
        count=count-1
    
    

    
    

    filepathsplit=file.split('\\')
    newfilename=""
    for f in filepathsplit:
      if '.xlsx'  in f:
        newfilename=newfilename+f

    wb.SaveAs(path+'executed\\'+newfilename)
    wb.Close()
    xl.Quit()
    os.system('taskkill /f /im Excel.exe')


os.system('taskkill /f /im Excel.exe')



import numpy as np
import pandas as pd
d=pd.read_excel(path+'executed\\'+"Data Set.xlsx","Sheet1")

import plotly.offline as plotly
from plotly.graph_objs import Scatter, Figure, Layout

plotly.plot([Scatter(x=d['Time,s'], y=d[' Tension, kN'] )])