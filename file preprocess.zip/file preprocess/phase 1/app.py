

path="E:\Projects\VisualCal\\"
'''import Statements'''
import win32com.client
import pandas as pd
import glob, os, shutil

if os.path.exists(path+"executed"):
  shutil.rmtree(path+"executed")

if not os.path.exists(path+"executed"):
  os.makedirs(path+"executed")
  print('created')

os.system('taskkill /f /im Excel.exe')
os.system('taskkill /f /im Excel.exe')

'''
runninng server message
import ctypes
MessageBox = ctypes.windll.user32.MessageBoxW
MessageBox(None, 'Local server is now Active.', 'Run Server', 0)
'''

'''import pandas as pd
df=pd.read_excel("Data Set.xlsx","Sheet1")
print(type(df.iloc[0]))
print(type(df))
'''

""" Make new folder 'executed' 

newpath = r'C:\Program Files\ arbitrary' 
if not os.path.exists(newpath):
    os.makedirs(newpath)

import glob, os, shutil

files = glob.iglob(os.path.join(source_dir, "*.xlsx"))
for file in files:
    if os.path.isfile(file):
        shutil.copy2(file, dest_dir)
"""
files = glob.iglob(os.path.join(path, "*.xlsx"))
for file in files:
  if '~' not in file:
    import win32com.client
    filename = file
    print(filename)
    sheetname = 'Sheet1'
    xl = win32com.client.DispatchEx('Excel.Application')
    wb = xl.Workbooks.Open(Filename=filename) 
    ws = wb.Sheets(sheetname)
    '''remove empty row from excel files'''
    begrow = 1
    endrow = ws.UsedRange.Rows.Count
    for row in range(begrow,10):
      if "Period" not in str(ws.Range('A{}'.format(begrow)).Value):
        ws.Range('A{}'.format(begrow)).EntireRow.Delete(Shift=-4162) # shift up
      else:
        break
    
    ws.Range('A{}'.format(begrow)).EntireRow.Delete(Shift=-4162)
    ws.Range('A{}'.format(begrow)).EntireRow.Delete(Shift=-4162)

    filepathsplit=file.split('\\')
    print(filepathsplit)
    newfilename=""
    for f in filepathsplit:
      if '.xlsx'  in f:
        newfilename=newfilename+f

    wb.SaveAs(path+'executed\\'+newfilename)
    wb.Close()
    xl.Quit()
    os.system('taskkill /f /im Excel.exe')

os.system('taskkill /f /im Excel.exe')
os.system('taskkill /f /im Excel.exe')
'''files = glob.iglob(os.path.join(path, "*.xlsx"))
for file in files:
  if '~' not in file:
    print(file,type(file))
    if os.path.isfile(file):'''


